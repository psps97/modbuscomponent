#!/bin/env python3

import json
import time
import sys
import traceback
import uuid

from datetime import datetime

import awsiot.greengrasscoreipc.clientv2 as clientV2
from awsiot.greengrasscoreipc.clientv2 import GreengrassCoreIPCClientV2
from awsiot.greengrasscoreipc.model import (
    PublishMessage,
    BinaryMessage,
    SubscriptionResponseMessage,
    UnauthorizedError
)

def main():

    pub_topic = "modbus/request/test"
    sub_topic = "modbus/response/test"
    
    with open('request-payload.json', 'r') as f:
        json_data = json.load(f)
        print(json.dumps(json_data) )
        
    function = json_data['ReadHoldingRegisters']['function']
    address = json_data['ReadHoldingRegisters']['address']
    quantity = json_data['ReadHoldingRegisters']['quantity']

    #x = {
    #    "id": str(uuid.uuid4().fields[-1])[:5],
    #    "function": "ReadHoldingRegisters",
    #    "address": 1,
    #    "quantity": 1
    #}
    
    x = {
        "id": str(uuid.uuid4().fields[-1])[:5],
        "function": function,
        "address": address,
        "quantity": quantity
    }

    message = json.dumps(x)
    print(message)

    try:
        ipc_client = GreengrassCoreIPCClientV2()
        
        # Subscription operations return a tuple with the response and the operation.
        _, operation = ipc_client.subscribe_to_topic(topic=sub_topic, on_stream_event=on_stream_event,
                                                     on_stream_error=on_stream_error, on_stream_closed=on_stream_closed)
        print('Successfully subscribed to topic: ' + sub_topic)
        # Keep the main thread alive, or the process will exit.
        try:
            while True:
                publish_binary_message_to_topic(ipc_client, pub_topic, message)
                print('Successfully published to topic: ' + pub_topic)
                time.sleep(10)
        except InterruptedError:
            print('Subscribe interrupted.')

        # To stop subscribing, close the stream.
        operation.close()
    except UnauthorizedError:
        print('Unauthorized error while subscribing to topic: ' +
              sub_topic, file=sys.stderr)
        traceback.print_exc()
        exit(1)
    except Exception:
        print('Exception occurred', file=sys.stderr)
        traceback.print_exc()
        exit(1)
        
    except Exception:
        print('Exception occurred', file=sys.stderr)
        traceback.print_exc()
        exit(1)


def publish_binary_message_to_topic(ipc_client, topic, message):
    binary_message = BinaryMessage(message=bytes(message, 'utf-8'))
    publish_message = PublishMessage(binary_message=binary_message)
    return ipc_client.publish_to_topic(topic=topic, publish_message=publish_message)


def on_stream_event(event: SubscriptionResponseMessage) -> None:
    try:
        message = str(event.binary_message.message, 'utf-8')
        topic = event.binary_message.context.topic
        print('Received new message on topic %s: %s' % (topic, message))
        
        t = datetime.utcnow() 
        timeInSeconds = int((t-datetime(1970,1,1)).total_seconds())
            
        telemetry_data = {
            "timestamp": int(round(time.time() * 1000)),
            "data": message
        }

        topic = "ggv2/test/telemetry"
        qos = '1'
        payload = json.dumps(telemetry_data).encode()

        try:
            ipc_core_client = GreengrassCoreIPCClientV2()
            result = ipc_core_client.publish_to_iot_core(topic_name=topic, qos=qos, payload=payload)
            #ipc_core_client.close()
            print("successfully published message:", result)
        except Exception as e:
            print("failed to publish mqtt message:", e)
        ###################################
    except:
        traceback.print_exc()


def on_stream_error(error: Exception) -> bool:
    print('Received a stream error.', file=sys.stderr)
    traceback.print_exc()
    return False  # Return True to close stream, False to keep stream open.


def on_stream_closed() -> None:
    print('Subscribe to topic stream closed.')


if __name__ == '__main__':
    main()

