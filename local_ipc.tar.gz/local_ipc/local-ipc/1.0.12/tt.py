#!/bin/env python3

import json
import time
import sys
import traceback
import uuid

from datetime import datetime

def main():

    pub_topic = "modbus/request/test"
    sub_topic = "modbus/response/test"
    message_list = [ ]
    
    with open('./request-payload.json', 'r') as f:
        json_datas = json.load(f)
        #print(json.dumps(json_datas))
        
        json_registers = json_datas['Registers']
        
        for k in json_registers:
            function = k['function']
            address = k['address']
            quantity = k['quantity']
            
            x = {
                "id": str(uuid.uuid4().fields[-1])[:5],
                "function": function,
                "address": address,
                "quantity": quantity
            }

            message = json.dumps(x)
            message_list.append(message)
    
    
    for message in message_list:
        print(message)
    #print(message_list)
    #x = {
    #    "id": str(uuid.uuid4().fields[-1])[:5],
    #    "function": "ReadHoldingRegisters",
    #    "address": 1,
    #    "quantity": 1
    #}


if __name__ == '__main__':
    main()

