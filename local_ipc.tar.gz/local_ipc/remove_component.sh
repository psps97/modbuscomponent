sudo /greengrass/v2/bin/greengrass-cli deployment create --remove="local-ipc"
