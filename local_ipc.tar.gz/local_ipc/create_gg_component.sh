echo ==--------Creating Component---------==
sudo /greengrass/v2/bin/greengrass-cli deployment create \
  --recipeDir ./recipes \
  --artifactDir . \
  --merge "local-ipc=1.0.12"
echo .